# Data and benchmark results

Numerical arrays are stored in NumPy NPZ archives and can be loaded with
`np.load(path, allow_pickle=False)`. Fields use interior-node ordering `(x, y)`
with coordinates `i/(n+1)` for `i=1,...,n`. The PDE, coefficient fields and
load fields are dimensionless.

| File | Contents |
|---|---|
| `material_examples.npz` | Four 96 x 96 coefficient fields and four load fields |
| `routing_example.npz` | Source and target coefficient fields on a 64 x 64 grid, with a load field |
| `routing_model.npz` | Network weights and training feature normalization |
| `routing_inputs.npz` | 216 routing feature vectors, predicted costs, route decisions and case identifiers |
| `provenance.json` | Dataset metadata, array layouts and SHA-256 fingerprints |

## Material fields and loads

`confirmation_closed` and `confirmation_gapped` contain the closed and
gapped single-ellipse coefficient fields used for space construction.
`reuse_closed` and `reuse_gapped` contain the coefficient fields used for
the local-reuse transition. Each pair contains realization 0 of its cohort.
The load array contains the anchor, Gaussian, dipole and spectral fields at
zero-based indices 0, 4, 5 and 6 of the 64-load bank. These loads are used
by the material-space and local-reuse workflows.

## Routing data

The routing transition uses the forward single-ellipse realization 0 at
amplitude 0.01 on the 64 x 64 grid. Its coefficient fields come from the
recorded coefficient interpolation.

The feature order is defined by `mixed_spaces.routing.FEATURES`: log grid
size, log load count, five face-change statistics, changed-face fraction,
two log10 minimum coefficients and two log10 initial relative-residual
statistics. Features use natural logarithms where their names specify `log`
and base-10 logarithms where they specify `log10`. The model outputs natural
logarithms of direct and reuse route costs in seconds.

`routing_inputs.npz` stores features, predictions and route decisions in
case order. `case_keys` associates each row with its geometry, grid,
transition direction, amplitude and load count. `routing_model.npz` stores
the seed-17 checkpoint and the feature means and standard deviations used
for inference.

## Benchmark tables

`results/confirmation_pairs.csv` contains 2,592 paired comparisons. Its
columns identify grid size (`n`), load count (`q`), geometry family, cohort,
realization, topology and comparator pair. `cost_ratio` and `iteration_ratio`
give the corresponding dimensionless ratios of recorded measurements.

`results/confirmation_accuracy.csv` contains accuracy summaries for the
four solver routes. Field and energy errors compare solutions of the same
discrete system against sparse LU; residuals are evaluated in the original
discrete equation.
