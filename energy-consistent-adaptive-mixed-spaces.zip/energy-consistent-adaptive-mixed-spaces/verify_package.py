"""Verify the sizes and SHA-256 fingerprints of the distributed files."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    seen = set()
    for row in manifest['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or row['path'] in seen:
            raise ValueError('Invalid manifest path')
        path = root / relative
        if not path.resolve().is_relative_to(root):
            raise ValueError('File is outside the package')
        content = path.read_bytes()
        if len(content) != row['bytes'] or hashlib.sha256(content).hexdigest() != row['sha256']:
            raise ValueError('Missing or changed file: ' + row['path'])
        seen.add(row['path'])
    print(json.dumps({'status': 'PASS', 'verified_files': len(seen)}, indent=2))


if __name__ == '__main__':
    main()
