# Energy-consistent adaptive mixed spaces

Code for **Energy-consistent adaptive mixed spaces for topology-changing
diffusion and repeated-load solves**.

The energy-consistent adaptive mixed-space framework combines exact local
particular responses, a protected global trace space, material-compartment enrichment,
Schur-energy selection and original-equation acceptance. A trained cost
predictor selects numerical routes after a material change.

## Installation

Use Python 3.11 or later and install the dependencies:

```bash
python -m pip install -r requirements.txt
```

To install the library:

```bash
python -m pip install .
```

## Running the code

Run these commands from the repository root:

```bash
python -m scripts.material_space
python -m scripts.local_reuse
python -m scripts.learned_routing
python -m scripts.confirmation_table
```

Each workflow prints its numerical results and saves a JSON file in `outputs/`.
Input paths are resolved relative to the repository. The workflows run on a CPU.

Run the numerical tests and file-integrity check with:

```bash
python -m unittest discover -s tests -v
python verify_package.py
```

## Implementation

| Module | Computational role |
|---|---|
| `operators.py` | Harmonic-face diffusion with homogeneous Dirichlet data |
| `condensation.py` | Exact banded interior elimination and balanced correction |
| `spaces.py` | Compartment enrichment, two-pass energy projection and Ritz selection |
| `queries.py` | Independent batch CG, full-field reconstruction and residual checks |
| `reuse.py` | Exact matching of local factors, coupling and particular responses |
| `routing.py` | Trained cost prediction and checked route execution |

The retained correction combines six protected directions with eighteen
complementary directions. The mixed and global constructions each use
thirty-six complementary candidates. Material compartments use four-neighbor
connectivity at the coefficient threshold 0.1.

## Numerical workflows

`material_space` solves four loads for closed and gapped barriers on a
96 x 96 grid. It constructs the mixed and matched global spaces, reports
candidate and retained ranks, and evaluates reconstructed fields against
an independently factored full discrete system.

`local_reuse` solves a closed-to-gapped material transition, retaining
unchanged local factors and particular responses. Twelve local blocks are
reused and four are updated. The target fields are checked against fresh
condensation and full sparse LU.

`learned_routing` applies the trained 12--24--24--2 cost predictor with tanh
activations and 962 parameters. It evaluates 216 routing cases, yielding
36 reuse decisions and 180 direct decisions, and executes a source-to-target
transition through the selected numerical backend. Numerical solves and
original-equation residual checks determine the completed fields.

`confirmation_table` reconstructs complete-cost and iteration comparisons
from the recorded paired benchmark results. The table includes parameter
pairs, topology states, workload prefixes and comparator families. Its cost
ratios describe the recorded benchmark measurements.

## Data and verification

`data/README.md` documents array layouts, routing features and benchmark
fields. `data/provenance.json` records dataset identifiers and fingerprints.
`docs/method_map.md` maps the manuscript's methods to the implementation.
`VERIFICATION.md` documents numerical checks. `manifest.json` contains file
sizes and SHA-256 fingerprints for the integrity check.

## Citation

The manuscript title is **Energy-consistent adaptive mixed spaces for
topology-changing diffusion and repeated-load solves**. A BibTeX entry is
provided in `CITATION.bib`.
