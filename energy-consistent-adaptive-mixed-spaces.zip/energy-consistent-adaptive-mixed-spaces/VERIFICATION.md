# Numerical verification

Verified on Windows with Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and
threadpoolctl 3.6.0. All 24 unit tests and all four numerical workflows passed.

## Run the checks

From the repository root, run:

```bash
python -m unittest discover -s tests -v
python -m scripts.material_space
python -m scripts.local_reuse
python -m scripts.learned_routing
python -m scripts.confirmation_table
python verify_package.py
```

The numerical workflows use one BLAS thread and save results in `outputs/`.

## Test coverage

The 24 unit tests check stencil/matrix agreement, operator symmetry and
positivity, exact condensation, harmonic-energy identities, balanced
correction, energy-rank rejection, retained-space containment,
target-operator actions, load validation, exact cache dependencies,
route recovery, model dimensions, routing predictions and paired-table
reconstruction.

## Space construction and full-field solutions

The material workflow checks closed and gapped barriers on the 96 x 96
grid, with four loads and both mixed and matched global constructions.
It reports a retained rank of 24, the energy Gram defect,
original-equation residuals, and field and energy errors against sparse LU
on the same grid. The solver accepts a reconstructed field when its
relative original-equation residual is at most 1.05e-8.

For the distributed material fields, the maximum relative residual is
9.582e-9 and the maximum energy Gram defect is 2.960e-14.

## Local reuse

The local-reuse workflow checks twelve reused blocks out of sixteen and
compares target fields with fresh condensation and full sparse LU.
The tests also check that a changed local load invalidates its cached
particular response and that cached arrays are read-only.

The target fields agree with fresh condensation, with a maximum absolute
difference of 0.0. The maximum relative field error against full sparse LU
is 1.682e-14.

## Routing and benchmark reconstruction

The routing tests check the 962-parameter network, all 216 recorded
predictions, 36 reuse decisions and 180 direct decisions. They check
completed equations for learned routing, target-factor recovery and
direct routing. The table test checks both 64-load pooled cost medians
against the paired benchmark data.

The maximum difference between predicted and recorded logarithmic costs is
0.0, and all 216 route decisions agree with the recorded decisions.

## File integrity

`manifest.json` records the size and SHA-256 fingerprint of each
distributed file except the manifest itself. `python verify_package.py`
validates these entries. Generated outputs are stored separately in
`outputs/`.
