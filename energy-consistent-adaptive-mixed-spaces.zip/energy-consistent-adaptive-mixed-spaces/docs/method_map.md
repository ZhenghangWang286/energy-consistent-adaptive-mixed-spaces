# Methods and implementation

| Method | Implementation | Workflow |
|---|---|---|
| Continuous problem and discrete operator; harmonic face conductance | `operators.Diffusion` | `material_space` |
| Exact local elimination and harmonic trace representation | `condensation.BandedCondensedSystem` | `material_space`, `local_reuse` |
| Protected global directions and material compartments | `spaces.protected_space`, `spaces._components` | `material_space` |
| Direct energy projection and fixed-rank selection | `spaces.EnergyFrame`, `spaces.energy_control_space` | `material_space` |
| Matched 36-candidate global construction | `spaces.optimized_global36` | `material_space` |
| Balanced interface correction and the query path | `queries.balanced_batch`, `queries.solve_batch` | `material_space` |
| Exact reuse after a local material change | `reuse.ReusableCondensedSystem`, `reuse.solve_responses` | `local_reuse` |
| Learned numerical-work allocation; supplementary routing architecture | `routing.Predictor`, `routing.features`, `routing.execute` | `learned_routing` |
| Complete-cost benchmark comparison | `results/confirmation_pairs.csv` | `confirmation_table` |

The solver uses row vectors for stored trace bases. If `basis` is Z transposed,
the energy identity is `basis @ actions.T = I`, with `actions = basis @ S`.
The retained basis combines all six protected rows with the first eighteen
Ritz-ordered complementary rows.

Each accepted material proposal is projected twice against the existing energy
frame. Its actual Schur action is recomputed before testing the relative energy
rank threshold of 1e-9. The initial global complement remains contained in the
42-direction candidate frame. Ritz selection minimizes the projected
`S D^(-1) S` objective at the fixed output rank.

Interior factors depend on the local matrix. Harmonic responses additionally
depend on the trace coupling. Particular responses depend on the local matrix
and the sampled load. For each target state, the Schur matrix is assembled
and factored using the current local blocks.

The routing predictor standardizes twelve observed features using stored
training statistics and returns two logarithmic costs. Route index zero is
fresh target LU; route index one is source-factor-preconditioned batch CG. A
route requiring recovery is completed by target LU with its work recorded.
Complete-trajectory costs include the source solve and the subsequent target
solve.

The trained cost network implements supervised selection of numerical routes.
