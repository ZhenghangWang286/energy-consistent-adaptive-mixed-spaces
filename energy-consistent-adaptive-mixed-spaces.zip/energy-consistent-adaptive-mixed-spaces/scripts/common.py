"""Shared paths and output handling for the scripts."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'


def emit(name, result):
    text = json.dumps(result, indent=2, allow_nan=False)
    print(text)
    folder = ROOT / 'outputs'
    folder.mkdir(exist_ok=True)
    (folder / (name + '.json')).write_text(text + '\n', encoding='utf-8')
    return result
