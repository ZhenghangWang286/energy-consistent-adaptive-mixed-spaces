"""Material-aware and matched global spaces for closed and gapped barriers."""
import numpy as np
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_limits

from mixed_spaces import (Diffusion, BandedCondensedSystem, energy_control_space,
                             optimized_global36, retained_basis, solve_batch)
from .common import DATA, emit


def run():
    records = []
    with np.load(DATA / 'material_examples.npz', allow_pickle=False) as data:
        loads = data['loads'].copy()
        for topology in ('closed', 'gapped'):
            system = BandedCondensedSystem(Diffusion(data['confirmation_' + topology]))
            banks = {}
            for method, constructor in (('mixed', energy_control_space),
                                        ('global', optimized_global36)):
                bank, detail = constructor(system)
                basis, actions = retained_basis(bank)
                fields, result = solve_batch(system, basis, actions, loads)
                banks[method] = (fields, result, detail, basis, actions)
            reference = splu(system.matrix.tocsc()).solve(
                loads.reshape(len(loads), -1).T).T
            for method, (fields, result, detail, basis, actions) in banks.items():
                errors = fields.reshape(len(loads), -1) - reference
                field_error = np.linalg.norm(errors, axis=1) / np.linalg.norm(reference, axis=1)
                numerator = np.sum(errors * (system.matrix @ errors.T).T, axis=1)
                denominator = np.sum(reference * (system.matrix @ reference.T).T, axis=1)
                energy_error = np.sqrt(np.maximum(numerator, 0.) / denominator)
                records.append({
                    'topology': topology, 'method': method, 'n': system.n,
                    'loads': len(loads), 'protected_rank': 6,
                    'complementary_candidates': detail['candidate_rank'], 'retained_rank': len(basis),
                    'energy_gram_defect': float(np.linalg.norm(
                        basis @ actions.T - np.eye(len(basis)), ord=np.inf)),
                    'iterations': result['iterations'],
                    'max_relative_residual': max(result['relative_residual']),
                    'max_same_grid_field_error': float(field_error.max()),
                    'max_same_grid_energy_error': float(energy_error.max())
                })
    return emit('material_space', {'equation': 'diffusion-reaction, rho=0.2',
                                  'records': records})


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        run()
