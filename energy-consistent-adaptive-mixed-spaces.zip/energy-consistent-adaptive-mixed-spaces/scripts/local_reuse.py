"""Recover unchanged local work in a recorded closed-to-gapped transition."""
import numpy as np
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_limits

from mixed_spaces import build_reusable, solve_responses
from .common import DATA, emit


def run():
    with np.load(DATA / 'material_examples.npz', allow_pickle=False) as data:
        loads = data['loads'].copy()
        source = build_reusable(data['reuse_closed'])
        _, source_result, cache = solve_responses(source, loads)
        target = build_reusable(data['reuse_gapped'], previous=source['system'])
        fields, result, _ = solve_responses(target, loads, previous=cache)
        fresh = build_reusable(data['reuse_gapped'])
        fresh_fields, _, _ = solve_responses(fresh, loads)
    reference = splu(target['system'].matrix.tocsc()).solve(
        loads.reshape(len(loads), -1).T).T.reshape(loads.shape)
    difference = float(np.max(np.abs(fields - fresh_fields)))
    error = np.linalg.norm((fields-reference).reshape(len(loads), -1), axis=1)
    error /= np.linalg.norm(reference.reshape(len(loads), -1), axis=1)
    metadata = target['system'].cache_metadata()
    if metadata['factors_reused'] != 12 or not np.allclose(fields, fresh_fields,
                                                         rtol=1e-11, atol=1e-12):
        raise ArithmeticError('Local reuse does not match the recorded transition')
    return emit('local_reuse', {
        'n': target['system'].n, 'loads_per_state': len(loads),
        'local_blocks': metadata['block_count'], 'factors_reused': metadata['factors_reused'],
        'response_operators_reused': metadata['response_operators_reused'],
        'particular_responses_reused': sum(result['particulars_reused']),
        'max_source_residual': max(source_result['relative_residual']),
        'max_target_residual': max(result['relative_residual']),
        'max_difference_from_fresh_condensation': difference,
        'max_same_grid_field_error': float(error.max())
    })


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        run()
