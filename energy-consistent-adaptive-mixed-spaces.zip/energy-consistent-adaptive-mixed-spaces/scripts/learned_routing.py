"""Evaluate the cost predictor and execute a numerical route."""
import numpy as np
from threadpoolctl import threadpool_limits

from mixed_spaces.routing import Predictor, execute
from .common import DATA, emit


def run():
    model = Predictor.load(DATA / 'routing_model.npz')
    with np.load(DATA / 'routing_inputs.npz', allow_pickle=False) as data:
        predicted = np.stack([model.predict(row) for row in data['features']])
        routes = np.argmin(predicted, axis=1)
        if not np.array_equal(routes, data['route_indices']):
            raise ArithmeticError('Routing decisions differ from the archived primary model')
        defect = float(np.max(np.abs(predicted-data['predicted_log_costs'])))
    with np.load(DATA / 'routing_example.npz', allow_pickle=False) as data:
        _, _, result = execute(data['source'], data['target'], data['loads'],
                               route='learned', model=model)
    return emit('learned_routing', {
        'architecture': [12, 24, 24, 2], 'parameters': sum(w.size+b.size for w, b in model.weights),
        'cases_replayed': len(routes), 'direct_selected': int(np.sum(routes == 0)),
        'reuse_selected': int(np.sum(routes == 1)), 'max_log_cost_replay_defect': defect,
        'example_chosen_route': result['chosen'], 'example_recovery': result['recovery'],
        'example_max_source_residual': max(result['source_residual']),
        'example_max_target_residual': max(result['target_residual']),
        'example_work': result['work']
    })


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        run()
