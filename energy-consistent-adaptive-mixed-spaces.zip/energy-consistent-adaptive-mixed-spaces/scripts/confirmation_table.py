"""Reconstruct the manuscript's 64-load paired confirmation table."""
import csv
import numpy as np

from .common import ROOT, emit


def run():
    with (ROOT / 'results/confirmation_pairs.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    results = []
    for n in (64, 96):
        for topology in ('closed', 'gapped', 'pooled'):
            group = [row for row in rows if int(row['n']) == n and int(row['q']) == 64
                     and row['topology'] == topology
                     and row['comparison'] == 'energy_exact_vs_global36']
            if len(group) != 24:
                raise ValueError('The complete 24-parameter endpoint is required')
            cost = np.array([float(row['cost_ratio']) for row in group])
            iterations = np.array([float(row['iteration_ratio']) for row in group])
            results.append({'n': n, 'topology': topology, 'independent_parameters': len(group),
                            'median_complete_cost_ratio': float(np.median(cost)),
                            'complete_cost_wins': int(np.sum(cost < 1.)),
                            'median_iteration_ratio': float(np.median(iterations))})
    return emit('confirmation_table', {'loads_per_operator': 64,
                                       'comparison': 'mixed / matched global', 'records': results})


if __name__ == '__main__':
    run()
