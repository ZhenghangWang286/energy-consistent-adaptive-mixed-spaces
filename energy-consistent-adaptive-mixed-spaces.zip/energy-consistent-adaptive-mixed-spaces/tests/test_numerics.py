"""Equation, energy and exact-reuse checks."""
from pathlib import Path
import unittest

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_limits

from mixed_spaces import (Diffusion, BandedCondensedSystem, energy_control_space,
                             optimized_global36, retained_basis, solve_batch,
                             build_reusable, solve_responses)
from mixed_spaces.condensation import TraceInverse, trace_space, _pack_lower_band
from mixed_spaces.operators import coordinates, fixed_directions
from mixed_spaces.spaces import EnergyFrame, analytic_vectors, containment_error

DATA = Path(__file__).resolve().parents[1] / 'data'


class OperatorTests(unittest.TestCase):
    def test_stencil_and_sparse_actions_agree(self):
        x, y = coordinates(16)
        operator = Diffusion(0.1 + x + y)
        values = np.stack((np.sin(np.pi*x)*np.sin(np.pi*y), x*y))
        expected = (operator.matrix() @ values.reshape(2, -1).T).T.reshape(values.shape)
        np.testing.assert_allclose(operator.apply(values), expected, rtol=1e-12, atol=1e-12)

    def test_operator_is_symmetric_positive_definite(self):
        operator = Diffusion(np.full((8, 8), 0.07))
        matrix = operator.matrix().toarray()
        np.testing.assert_array_equal(matrix, matrix.T)
        self.assertGreater(np.linalg.eigvalsh(matrix).min(), 0.)

    def test_nonfinite_or_nonpositive_inputs_are_rejected(self):
        for field in (np.zeros((4, 4)), np.full((4, 4), np.nan),
                      np.full((4, 4), np.inf), np.ones((4, 5))):
            with self.assertRaises(ValueError):
                Diffusion(field)
        with self.assertRaises(ValueError):
            Diffusion(np.ones((4, 4)), reaction=-1.)

    def test_row_wrap_coupling_is_rejected(self):
        matrix = sparse.eye(6, format='lil') * 4.
        matrix[2, 3] = matrix[3, 2] = -1.
        with self.assertRaises(ValueError):
            _pack_lower_band(matrix.tocsr(), (2, 3))


class EnergyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pool = threadpool_limits(limits=1)
        x, y = coordinates(16)
        cls.system = BandedCondensedSystem(Diffusion(.2 + x*y))

    @classmethod
    def tearDownClass(cls):
        cls.pool.restore_original_limits()

    def test_harmonic_energy_identity(self):
        system = self.system
        identity = np.eye(len(system.trace))
        extension = np.stack([system.expand(q).ravel() for q in identity]).T
        reduced = extension.T @ (system.matrix @ extension)
        np.testing.assert_allclose(reduced, system.schur, rtol=1e-11, atol=1e-11)

    def test_condensation_and_reconstruction_equal_full_solve(self):
        system = self.system
        rhs = np.ones((system.n, system.n))
        reduced, particulars = system.condense(rhs)
        field = system.expand(np.linalg.solve(system.schur, reduced), particulars)
        expected = splu(system.matrix.tocsc()).solve(rhs.ravel()).reshape(rhs.shape)
        np.testing.assert_allclose(field, expected, rtol=1e-11, atol=1e-12)

    def test_balanced_action_is_positive_and_exact_on_retained_space(self):
        system = self.system
        raw = fixed_directions(system.n, 6).reshape(6, -1)[:, system.trace]
        basis, actions = trace_space(system.schur, raw)
        inverse = TraceInverse(system.diagonal, basis, actions)
        matrix = np.stack([inverse.apply(row) for row in np.eye(len(system.trace))]).T
        np.testing.assert_allclose(matrix, matrix.T, rtol=1e-11, atol=1e-13)
        self.assertGreater(np.linalg.eigvalsh((matrix+matrix.T)*.5).min(), 0.)
        np.testing.assert_allclose(matrix @ system.schur @ basis.T, basis.T,
                                   rtol=1e-10, atol=1e-11)

    def test_energy_frame_rejects_dependence(self):
        diagonal = np.arange(1, 13, dtype=float)
        matrix = np.diag(diagonal)
        basis = np.eye(12)[:6] / np.sqrt(diagonal)
        frame = EnergyFrame(matrix, basis, basis @ matrix, 8)
        accepted, _ = frame.append(np.eye(12)[0])
        self.assertFalse(accepted)
        accepted, _ = frame.append(np.eye(12)[6])
        self.assertTrue(accepted)
        np.testing.assert_allclose(frame.basis[:frame.size] @ frame.actions[:frame.size].T,
                                   np.eye(frame.size), rtol=1e-12, atol=1e-12)


class MaterialSpaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pool = threadpool_limits(limits=1)
        with np.load(DATA / 'material_examples.npz', allow_pickle=False) as data:
            cls.loads = data['loads'].copy()
            cls.closed = BandedCondensedSystem(Diffusion(data['confirmation_closed']))
            cls.gapped = BandedCondensedSystem(Diffusion(data['confirmation_gapped']))
        cls.bank, cls.detail = energy_control_space(cls.closed)

    @classmethod
    def tearDownClass(cls):
        cls.pool.restore_original_limits()

    def test_candidate_and_retained_ranks(self):
        bank = self.bank
        self.assertEqual((len(bank[0]), len(bank[2])), (6, 36))
        basis, actions = retained_basis(bank)
        self.assertEqual(len(basis), 24)
        np.testing.assert_allclose(basis @ actions.T, np.eye(24), rtol=1e-7, atol=1e-7)

    def test_initial_global_span_is_contained(self):
        bank = self.bank
        basis = np.concatenate((bank[0], bank[2]))
        actions = np.concatenate((bank[1], bank[3]))
        defect = containment_error(self.closed, analytic_vectors(self.closed), basis, actions)
        self.assertLess(defect, 1e-7)
        self.assertLessEqual(self.detail['max_ritz_difference_from_global18'], 1e-9)

    def test_stored_actions_use_the_target_operator(self):
        bank = self.bank
        basis = np.concatenate((bank[0], bank[2]))
        actions = np.concatenate((bank[1], bank[3]))
        np.testing.assert_allclose(actions, basis @ self.closed.schur, rtol=1e-9, atol=1e-9)

    def test_connected_material_uses_the_same_global_bank(self):
        mixed, detail = energy_control_space(self.gapped)
        global_bank, _ = optimized_global36(self.gapped)
        self.assertEqual(detail['component_count'], 1)
        for first, second in zip(mixed, global_bank):
            np.testing.assert_array_equal(first, second)

    def test_completed_fields_match_a_same_grid_reference(self):
        basis, actions = retained_basis(self.bank)
        fields, result = solve_batch(self.closed, basis, actions, self.loads)
        reference = splu(self.closed.matrix.tocsc()).solve(self.loads.reshape(4, -1).T).T
        relative = np.linalg.norm(fields.reshape(4, -1)-reference, axis=1)
        relative /= np.linalg.norm(reference, axis=1)
        self.assertLess(max(result['relative_residual']), 1.05e-8)
        self.assertLess(relative.max(), 1e-7)

    def test_zero_or_nonfinite_load_is_rejected(self):
        basis, actions = retained_basis(self.bank)
        for loads in (np.zeros_like(self.loads), np.full_like(self.loads, np.nan)):
            with self.assertRaises(ValueError):
                solve_batch(self.closed, basis, actions, loads)


class LocalReuseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pool = threadpool_limits(limits=1)
        with np.load(DATA / 'material_examples.npz', allow_pickle=False) as data:
            cls.loads = data['loads'].copy()
            cls.source = build_reusable(data['reuse_closed'])
            cls.target_coefficient = data['reuse_gapped'].copy()
        _, _, cls.cache = solve_responses(cls.source, cls.loads)

    @classmethod
    def tearDownClass(cls):
        cls.pool.restore_original_limits()

    def test_recorded_twelve_blocks_are_reused_exactly(self):
        target = build_reusable(self.target_coefficient, previous=self.source['system'])
        fields, detail, _ = solve_responses(target, self.loads, previous=self.cache)
        fresh = build_reusable(self.target_coefficient)
        fresh_fields, _, _ = solve_responses(fresh, self.loads)
        self.assertEqual(target['system'].cache_metadata()['factors_reused'], 12)
        self.assertEqual(sum(detail['particulars_reused']), 12)
        np.testing.assert_array_equal(fields, fresh_fields)

    def test_changed_load_invalidates_only_its_local_response(self):
        loads = self.loads.copy()
        loads.reshape(len(loads), -1)[0, self.source['system'].blocks[0].indices] += .1
        target = build_reusable(self.source['operator'].a, previous=self.source['system'])
        fields, detail, _ = solve_responses(target, loads, previous=self.cache)
        self.assertFalse(detail['particulars_reused'][0])
        self.assertEqual(sum(detail['particulars_reused']), 15)
        fresh = build_reusable(self.source['operator'].a)
        expected, _, _ = solve_responses(fresh, loads)
        np.testing.assert_allclose(fields, expected, rtol=1e-11, atol=1e-12)

    def test_caches_own_readonly_arrays(self):
        self.assertFalse(self.cache.loads.flags.writeable)
        self.assertFalse(np.shares_memory(self.cache.loads, self.loads))
        for entry in self.source['system'].entries:
            self.assertFalse(entry.packed.flags.writeable)
            self.assertFalse(entry.block.factor[0].flags.writeable)
        for local in self.cache.particulars:
            self.assertFalse(local.flags.writeable)


if __name__ == '__main__':
    unittest.main()
