"""Numerical verification of Energy-consistent adaptive mixed spaces."""
