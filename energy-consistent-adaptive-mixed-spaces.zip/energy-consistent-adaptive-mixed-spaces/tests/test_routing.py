"""Checkpoint replay and equation-based route completion."""
import csv
from pathlib import Path
import unittest

import numpy as np
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_limits

from mixed_spaces import Diffusion
from mixed_spaces.routing import FEATURES, Predictor, execute

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'


class RoutingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pool = threadpool_limits(limits=1)
        cls.model = Predictor.load(DATA / 'routing_model.npz')
        with np.load(DATA / 'routing_example.npz', allow_pickle=False) as data:
            cls.source, cls.target, cls.loads = (data[name].copy()
                for name in ('source', 'target', 'loads'))

    @classmethod
    def tearDownClass(cls):
        cls.pool.restore_original_limits()

    def test_network_dimensions_and_parameter_count(self):
        self.assertEqual(len(FEATURES), 12)
        self.assertEqual(sum(w.size+b.size for w, b in self.model.weights), 962)

    def test_all_archived_predictions_and_routes_match(self):
        with np.load(DATA / 'routing_inputs.npz', allow_pickle=False) as data:
            predicted = np.stack([self.model.predict(row) for row in data['features']])
            routes = np.argmin(predicted, axis=1)
            self.assertEqual(len(routes), 216)
            self.assertEqual(int(np.sum(routes == 1)), 36)
            np.testing.assert_allclose(predicted, data['predicted_log_costs'],
                                       rtol=1e-13, atol=1e-13)
            np.testing.assert_array_equal(routes, data['route_indices'])

    def test_learned_reuse_finishes_the_target_equation(self):
        _, field, result = execute(self.source, self.target, self.loads,
                                   route='learned', model=self.model)
        self.assertEqual(result['chosen'], 'reuse')
        self.assertFalse(result['recovery'])
        reference = splu(Diffusion(self.target).matrix().tocsc()).solve(self.loads.ravel())
        np.testing.assert_allclose(field.ravel(), reference, rtol=1e-8, atol=1e-10)
        self.assertLess(max(result['target_residual']), 1.05e-8)

    def test_insufficient_reuse_budget_invokes_target_recovery(self):
        _, _, result = execute(self.source, self.target, self.loads,
                               route='reuse', maxiter=0)
        self.assertTrue(result['recovery'])
        self.assertEqual(result['work']['target_factorizations'], 1)
        self.assertLess(max(result['target_residual']), 1.05e-8)

    def test_invalid_predictor_uses_the_direct_route(self):
        _, _, result = execute(self.source, self.target, self.loads,
                               route='learned', model=None)
        self.assertEqual(result['chosen'], 'direct')
        self.assertEqual(result['failure'], 'invalid_predictor')
        self.assertLess(max(result['target_residual']), 1.05e-8)

    def test_invalid_features_and_normalization_are_rejected(self):
        with self.assertRaises(ValueError):
            self.model.predict(np.full(12, np.nan))
        with self.assertRaises(ValueError):
            self.model.predict(np.zeros(11))
        with self.assertRaises(ValueError):
            Predictor(self.model.mean, np.zeros(12), self.model.weights)


class TableTests(unittest.TestCase):
    def test_complete_primary_endpoint_and_manuscript_medians(self):
        with (ROOT / 'results/confirmation_pairs.csv').open(newline='', encoding='utf-8') as stream:
            rows = list(csv.DictReader(stream))
        for n, expected in ((64, 0.9133349528585977), (96, 0.928567851140479)):
            group = [r for r in rows if int(r['n']) == n and int(r['q']) == 64
                     and r['topology'] == 'pooled' and r['comparison'] == 'energy_exact_vs_global36']
            self.assertEqual(len(group), 24)
            self.assertAlmostEqual(np.median([float(r['cost_ratio']) for r in group]), expected, places=12)


if __name__ == '__main__':
    unittest.main()
