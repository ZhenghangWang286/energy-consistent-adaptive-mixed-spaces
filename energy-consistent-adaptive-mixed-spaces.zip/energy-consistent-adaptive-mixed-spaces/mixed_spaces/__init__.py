"""Energy-consistent adaptive mixed-space solvers for topology-changing diffusion."""
from .operators import Diffusion
from .condensation import BandedCondensedSystem
from .spaces import energy_control_space, optimized_global36
from .queries import retained_basis, solve_batch
from .reuse import build_reusable, solve_responses

__all__ = ['Diffusion', 'BandedCondensedSystem', 'energy_control_space',
           'optimized_global36', 'retained_basis', 'solve_batch',
           'build_reusable', 'solve_responses']
