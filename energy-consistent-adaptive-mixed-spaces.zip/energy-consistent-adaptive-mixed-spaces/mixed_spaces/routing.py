"""Trained cost prediction and checked numerical route execution."""
from dataclasses import dataclass
import time
import numpy as np
from scipy.sparse.linalg import splu

from .operators import Diffusion

FEATURES = ('log_n', 'log_q', 'max_log_face_ratio', 'mean_abs_log_face_ratio',
            'std_log_face_ratio', 'min_log_face_ratio', 'max_signed_log_face_ratio',
            'changed_face_fraction', 'log10_source_min', 'log10_target_min',
            'log10_max_initial_residual', 'log10_mean_initial_residual')

def validate_inputs(source, target, loads):
    for a in (source, target):
        if (a.ndim != 2 or a.shape[0] != a.shape[1] or
                not np.all(np.isfinite(a)) or np.min(a) <= 0):
            raise ValueError('Positive finite square material fields required')
    if (target.shape != source.shape or loads.ndim != 3 or
            loads.shape[1:] != source.shape or len(loads) < 1 or
            not np.all(np.isfinite(loads)) or
            np.any(np.linalg.norm(loads.reshape(len(loads), -1), axis=1) == 0)):
        raise ValueError('Compatible nonzero finite loads required')


def features(source, target, matrix, states, right, norms):
    ratios = np.concatenate((np.log(target.wx/source.wx).ravel(),
                             np.log(target.wy/source.wy).ravel()))
    residual = right - matrix @ states
    relative = np.linalg.norm(residual, axis=0)/norms
    x = np.array([np.log(source.n), np.log(len(norms)), np.max(np.abs(ratios)),
                  np.mean(np.abs(ratios)), np.std(ratios), np.min(ratios),
                  np.max(ratios), np.mean(np.abs(ratios) > 1e-3),
                  np.log10(source.a.min()), np.log10(target.a.min()),
                  np.log10(max(relative.max(), 1e-16)),
                  np.log10(max(relative.mean(), 1e-16))])
    if not np.all(np.isfinite(x)):
        raise ArithmeticError('Nonfinite routing features')
    return x, residual

@dataclass(frozen=True)
class Predictor:
    mean: np.ndarray
    scale: np.ndarray
    weights: tuple

    def __post_init__(self):
        if (np.shape(self.mean) != (12,) or np.shape(self.scale) != (12,)
                or not np.all(np.isfinite(self.mean))
                or not np.all(np.isfinite(self.scale)) or np.any(self.scale <= 0)
                or len(self.weights) != 3):
            raise ValueError('Invalid feature normalization or network depth')
        for (weight, bias), shape in zip(self.weights, ((24, 12), (24, 24), (2, 24))):
            if (np.shape(weight) != shape or np.shape(bias) != (shape[0],)
                    or not np.all(np.isfinite(weight)) or not np.all(np.isfinite(bias))):
                raise ValueError('Invalid network weights')

    def predict(self, x):
        x = np.asarray(x, dtype=float)
        if x.shape != (12,) or not np.all(np.isfinite(x)):
            raise ValueError('A finite twelve-feature vector is required')
        z = (x-self.mean)/self.scale
        for weight, bias in self.weights[:-1]:
            z = np.tanh(z @ weight.T + bias)
        weight, bias = self.weights[-1]
        result = z @ weight.T + bias
        if result.shape != (2,) or not np.all(np.isfinite(result)):
            raise ArithmeticError('Invalid predicted costs')
        return result

    def arrays(self):
        return (self.mean, self.scale, *(a for pair in self.weights for a in pair))

    def save(self, path):
        with path.open('xb') as stream:
            np.savez(stream, mean=self.mean, scale=self.scale,
                     **{f'w{i}': w for i, (w, b) in enumerate(self.weights)},
                     **{f'b{i}': b for i, (w, b) in enumerate(self.weights)})

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as data:
            return cls(data['mean'].copy(), data['scale'].copy(),
                       tuple((data[f'w{i}'].copy(), data[f'b{i}'].copy()) for i in range(3)))

def batch_reuse(matrix, factor, initial, right, norms, residual=None, maxiter=12):
    if type(maxiter) is not int or maxiter < 0:
        raise ValueError('Nonnegative integer iteration budget required')
    x = initial.copy(order='F')
    r = right-matrix@x if residual is None else residual.copy(order='F')
    iterations = np.zeros(right.shape[1], dtype=int)
    work = {'preconditioner_rhs': 0, 'matrix_rhs': 0, 'iterations_max': 0}
    active = np.flatnonzero(np.linalg.norm(r, axis=0)/norms > 1e-11)
    if not len(active):
        return x, iterations, work, None
    z = factor.solve(np.asfortranarray(r[:, active]))
    work['preconditioner_rhs'] += len(active)
    p = z.copy()
    rz = np.sum(r[:, active]*z, axis=0)
    for step in range(maxiter):
        action = matrix @ p
        work['matrix_rhs'] += len(active)
        curvature = np.sum(p*action, axis=0)
        if (not np.all(np.isfinite(curvature)) or np.any(curvature <= 0)
                or not np.all(np.isfinite(rz)) or np.any(rz <= 0)):
            return x, iterations, work, 'nonpositive_or_nonfinite_pcg'
        alpha = rz/curvature
        x[:, active] += p*alpha
        r[:, active] -= action*alpha
        iterations[active] += 1
        work['iterations_max'] = step+1
        keep = np.linalg.norm(r[:, active], axis=0)/norms[active] > 1e-11
        if not np.any(keep):
            break
        active, p, rz = active[keep], p[:, keep], rz[keep]
        if step+1 == maxiter:
            break
        z = factor.solve(np.asfortranarray(r[:, active]))
        work['preconditioner_rhs'] += len(active)
        next_rz = np.sum(r[:, active]*z, axis=0)
        p = z+p*(next_rz/rz)
        rz = next_rz
    return x, iterations, work, None


def analytic_score(x):
    # Feature 2 is the largest absolute log face-weight ratio.
    # Scale the corresponding relative face-weight change by the load count.
    return float(np.exp(x[1])*np.expm1(min(x[2], 30.)))


def execute(source, target, loads, route, model=None, threshold=None,
            feature_override=None, maxiter=12):
    started = time.perf_counter()
    source, target, loads = [np.asarray(a, dtype=float) for a in (source, target, loads)]
    validate_inputs(source, target, loads)
    right = np.asfortranarray(loads.reshape(len(loads), -1).T)
    norms = np.linalg.norm(right, axis=0)
    source_op = Diffusion(source)
    source_matrix = source_op.matrix().tocsc()
    source_factor = splu(source_matrix)
    source_states = source_factor.solve(right)
    source_residual = np.linalg.norm(right-source_matrix@source_states, axis=0)/norms
    source_seconds = time.perf_counter()-started
    target_started = time.perf_counter()
    target_op = Diffusion(target)
    matrix = target_op.matrix().tocsc()
    chosen, failure, observed, residual = route, None, None, None
    feature_seconds, inference_seconds = 0., 0.
    if route in ('learned', 'analytic', 'shuffled'):
        tick = time.perf_counter()
        observed, residual = features(source_op, target_op, matrix, source_states, right, norms)
        feature_seconds = time.perf_counter()-tick
        tick = time.perf_counter()
        if route == 'analytic':
            if threshold is None or np.isnan(threshold):
                raise ValueError('A frozen analytic threshold is required')
            chosen = 'reuse' if analytic_score(observed) <= threshold else 'direct'
        else:
            try:
                inputs = observed if feature_override is None else np.asarray(feature_override)
                costs = model.predict(inputs)
                chosen = ('direct', 'reuse')[int(np.argmin(costs))]
            except (ValueError, ArithmeticError, AttributeError):
                chosen, failure = 'direct', 'invalid_predictor'
        inference_seconds = time.perf_counter()-tick
    if chosen not in ('reuse', 'direct'):
        raise ValueError('Unknown backend')
    work = {'source_factorizations': 1, 'source_rhs': len(loads),
            'target_factorizations': 0, 'target_direct_rhs': 0,
            'preconditioner_rhs': 0, 'matrix_rhs': 0, 'iterations_max': 0}
    numerical_started = time.perf_counter()
    iterations = np.zeros(len(loads), dtype=int)
    recovery = False
    attempt_residual = None
    if chosen == 'reuse':
        states, iterations, reuse_work, issue = batch_reuse(
            matrix, source_factor, source_states, right, norms, residual, maxiter)
        work.update(reuse_work)
        true_residual = np.linalg.norm(right-matrix@states, axis=0)/norms
        finite = np.all(np.isfinite(states)) and np.all(np.isfinite(true_residual))
        attempt_residual = float(true_residual.max()) if finite else None
        if issue or not finite or true_residual.max() > 1e-10:
            recovery = True
            failure = issue or 'true_residual'
    if chosen == 'direct' or recovery:
        states = splu(matrix).solve(right)
        work['target_factorizations'] += 1
        work['target_direct_rhs'] += len(loads)
    numerical_seconds = time.perf_counter()-numerical_started
    tick = time.perf_counter()
    final_residual = np.linalg.norm(right-matrix@states, axis=0)/norms
    if (not np.all(np.isfinite(final_residual)) or final_residual.max() > 1.05e-8
            or source_residual.max() > 1.05e-8):
        raise ArithmeticError('Original equation residual failed')
    check_seconds = time.perf_counter()-tick
    target_seconds = time.perf_counter()-target_started
    total = time.perf_counter()-started
    metadata = {'total_seconds': total, 'source_seconds': source_seconds,
        'target_seconds': target_seconds, 'feature_seconds': feature_seconds,
        'inference_seconds': inference_seconds, 'numerical_seconds': numerical_seconds,
        'check_seconds': check_seconds,
        'target_overhead_seconds': target_seconds-feature_seconds-inference_seconds-numerical_seconds-check_seconds,
        'chosen': chosen, 'recovery': recovery, 'failure': failure,
        'attempt_residual': attempt_residual,
        'source_residual': source_residual.tolist(), 'target_residual': final_residual.tolist(),
        'iterations': iterations.tolist(), 'work': work,
        'features': None if observed is None else observed.tolist()}
    return source_states.T.reshape(loads.shape), states.T.reshape(loads.shape), metadata
