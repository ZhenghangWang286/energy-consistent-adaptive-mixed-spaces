"""Independent batched queries with original-equation acceptance."""
import numpy as np
from scipy import linalg

def condense_batch(system, loads):
    loads = np.asarray(loads, dtype=float)
    if loads.ndim != 3 or loads.shape[1:] != (system.n, system.n) or not len(loads) or not np.all(np.isfinite(loads)):
        raise ValueError('A finite, nonempty batch of compatible loads is required')
    flat = loads.reshape(len(loads), system.size).T
    reduced = flat[system.trace].copy()
    particulars = []
    for block in system.blocks:
        local = linalg.cho_solve_banded(block.factor, flat[block.indices], check_finite=False)
        reduced[block.trace_indices] -= block.coupling.T@local
        particulars.append(local)
    return np.ascontiguousarray(reduced.T), particulars


def expand_batch(system, traces, particulars):
    traces = np.asarray(traces, dtype=float)
    if traces.ndim != 2 or traces.shape[1] != len(system.trace) or len(particulars) != len(system.blocks):
        raise ValueError('Incompatible batch expansion')
    flat = np.zeros((system.size, len(traces)))
    flat[system.trace] = traces.T
    for block, local in zip(system.blocks, particulars):
        if local.shape != (len(block.indices), len(traces)):
            raise ValueError('Incompatible particular solutions')
        flat[block.indices] = local-block.extension@traces[:, block.trace_indices].T
    return np.ascontiguousarray(flat.T).reshape(len(traces), system.n, system.n)


def balanced_batch(residuals, diagonal, basis, actions):
    coefficients = residuals@basis.T
    smooth = (residuals-coefficients@actions)/diagonal
    return coefficients@basis+smooth-(smooth@actions.T)@basis


def independent_pcg_batch(schur, rhs, inverse, tolerances, maxiter=1000):
    """Separate scalar CG recurrences, no cross-RHS orthogonalization."""
    rhs = np.asarray(rhs, dtype=float)
    tolerances = np.asarray(tolerances, dtype=float)
    if rhs.ndim != 2 or schur.shape != (rhs.shape[1], rhs.shape[1]) or tolerances.shape != (len(rhs),):
        raise ValueError('Incompatible batched CG shapes')
    if not np.all(np.isfinite(rhs)) or not np.all(np.isfinite(tolerances)) or np.any(tolerances <= 0):
        raise ValueError('Finite RHS and strictly positive tolerances are required')
    if type(maxiter) is not int or maxiter < 1:
        raise ValueError('Positive iteration budget required')
    states = np.zeros_like(rhs)
    iterations = np.zeros(len(rhs), dtype=int)
    active = np.flatnonzero(np.linalg.norm(rhs, axis=1) >= tolerances)
    residual = rhs[active].copy()
    counts = []
    if len(active):
        z = inverse(residual)
        rho = np.sum(residual*z, axis=1)
        directions = z.copy()
        for _ in range(maxiter):
            counts.append(len(active))
            actions = directions@schur.T
            curvature = np.sum(directions*actions, axis=1)
            if np.any(rho <= 0) or np.any(curvature <= 0) or not np.all(np.isfinite(curvature)):
                raise ArithmeticError('Nonpositive CG energy')
            alpha = rho/curvature
            states[active] += alpha[:, None]*directions
            residual -= alpha[:, None]*actions
            iterations[active] += 1
            keep = np.linalg.norm(residual, axis=1) >= tolerances[active]
            active = active[keep]
            if not len(active):
                break
            residual = residual[keep]
            z = inverse(residual)
            new_rho = np.sum(residual*z, axis=1)
            directions = z+(new_rho/rho[keep])[:, None]*directions[keep]
            rho = new_rho
    info = np.zeros(len(rhs), dtype=int)
    info[active] = maxiter
    return states, {'iterations': iterations.tolist(), 'cg_info': info.tolist(),
                    'active_queries_per_step': counts, 'krylov_vector_actions': int(sum(counts))}

def solve_batch(system, basis, actions, loads):
    """Solve independent queries and check every reconstructed full equation."""
    loads = np.asarray(loads, dtype=float)
    if (loads.ndim != 3 or loads.shape[1:] != system.operator.shape
            or not len(loads) or not np.all(np.isfinite(loads))):
        raise ValueError('A finite, compatible load batch is required')
    norms = np.linalg.norm(loads.reshape(len(loads), -1), axis=1)
    if np.any(norms <= 0):
        raise ValueError('Nonzero loads are required')
    basis, actions = np.asarray(basis), np.asarray(actions)
    if basis.shape != actions.shape or basis.shape[1] != len(system.trace):
        raise ValueError('Incompatible retained basis and actions')
    reduced, particulars = condense_batch(system, loads)
    inverse = lambda r: balanced_batch(r, system.diagonal, basis, actions)
    traces, record = independent_pcg_batch(
        system.schur, reduced, inverse, 1e-8*norms)
    states = expand_batch(system, traces, particulars)
    residuals = np.linalg.norm(
        (loads-system.operator.apply(states)).reshape(len(loads), -1), axis=1)/norms
    if (max(record['cg_info']) != 0 or not np.all(np.isfinite(residuals))
            or max(residuals) > 1.05e-8):
        raise ArithmeticError('Original residual target not met')
    return states, {**record, 'relative_residual': residuals.tolist()}


def retained_basis(bank):
    """Select the protected six and the first eighteen Ritz directions."""
    base, base_action, complement, actions, _ = bank
    return (np.concatenate((base, complement[:18])),
            np.concatenate((base_action, actions[:18])))
