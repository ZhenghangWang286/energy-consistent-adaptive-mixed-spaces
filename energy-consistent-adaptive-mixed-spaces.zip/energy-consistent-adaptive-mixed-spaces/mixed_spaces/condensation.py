"""Exact interior elimination and balanced trace correction."""
from dataclasses import dataclass
import numpy as np
from scipy import linalg

@dataclass
class BandedInteriorBlock:
    indices: np.ndarray
    trace_indices: np.ndarray
    factor: tuple
    coupling: np.ndarray
    extension: np.ndarray
    interior_shape: tuple
    lower_bandwidth: int
    matrix_nnz: int

def _pack_lower_band(matrix, interior_shape):
    """Pack a sparse rectangular five-point block without densifying it.

    Local indices follow row-major order on interior_shape.  Checking physical
    neighbors, rather than merely allowable offsets, rejects a spurious edge
    between the end of one row and the beginning of the next.  The returned
    lower-band storage obeys ab[i-j, j] = A[i, j] for i >= j.
    """
    if len(interior_shape) != 2:
        raise ValueError('An interior must have two rectangular dimensions')
    height, width = interior_shape
    if (not isinstance(height, (int, np.integer))
            or not isinstance(width, (int, np.integer))
            or height < 1 or width < 1):
        raise ValueError('Interior dimensions must be positive integers')
    size = int(height * width)
    if matrix.shape != (size, size):
        raise ValueError('Local matrix and rectangular interior disagree')
    local = matrix.tocsr(copy=True)
    local.sum_duplicates()
    local.eliminate_zeros()
    if not np.all(np.isfinite(local.data)):
        raise ValueError('The local matrix must be finite')
    difference = local - local.T
    difference.eliminate_zeros()
    if difference.nnz:
        raise ValueError('The local matrix must be exactly symmetric')
    diagonal = local.diagonal()
    if np.any(diagonal <= 0.):
        raise ValueError('The local diagonal must be positive')
    entries = local.tocoo()
    off = entries.row != entries.col
    row_distance = np.abs(entries.row[off] // width - entries.col[off] // width)
    column_distance = np.abs(entries.row[off] % width - entries.col[off] % width)
    if np.any(row_distance + column_distance != 1):
        raise ValueError('Local matrix contains a non-neighbor or row-wrap edge')
    if np.any(entries.data[off] > 0.):
        raise ValueError('Five-point diffusion off-diagonal entries must be nonpositive')
    lower = entries.row >= entries.col
    offsets = entries.row[lower] - entries.col[lower]
    bandwidth = int(offsets.max(initial=0))
    if bandwidth > width:
        raise ValueError('Local matrix has entries outside its geometric bandwidth')
    packed = np.zeros((bandwidth + 1, size), dtype=np.float64, order='F')
    packed[offsets, entries.col[lower]] = entries.data[lower]
    return packed, bandwidth

class BandedCondensedSystem:
    """Exact banded elimination on rectangular interiors and one-node separators."""

    def __init__(self, operator, partitions=4):
        n = operator.n
        if type(partitions) is not int or not 2 <= partitions <= n // 2:
            raise ValueError('Partitions must leave nonempty block interiors')
        self.operator = operator
        self.matrix = operator.matrix()
        self.n = n
        self.size = n * n
        self.partitions = partitions
        cuts = np.array([n * j // partitions - 1 for j in range(1, partitions)], dtype=int)
        mask = np.zeros((n, n), dtype=bool)
        mask[cuts, :] = True
        mask[:, cuts] = True
        self.trace = np.flatnonzero(mask.ravel())
        if not len(self.trace):
            raise ValueError('At least two partitions are needed for a nonempty trace')
        self.mask = mask
        self.schur = self.matrix[self.trace][:, self.trace].toarray()
        starts, ends = np.r_[0, cuts + 1], np.r_[cuts, n]
        grid = np.arange(self.size).reshape(n, n)
        self.blocks = []
        for sx, ex in zip(starts, ends):
            for sy, ey in zip(starts, ends):
                indices = grid[sx:ex, sy:ey].ravel()
                interior_shape = (int(ex - sx), int(ey - sy))
                local = self.matrix[indices][:, indices].tocsr()
                packed, bandwidth = _pack_lower_band(local, interior_shape)
                cross = self.matrix[indices][:, self.trace]
                touched = np.unique(cross.indices)
                coupling = cross[:, touched].toarray()
                factor = (linalg.cholesky_banded(packed, lower=True,
                                                 check_finite=False), True)
                extension = linalg.cho_solve_banded(factor, coupling, check_finite=False)
                self.schur[np.ix_(touched, touched)] -= coupling.T @ extension
                self.blocks.append(BandedInteriorBlock(
                    indices, touched, factor, coupling, extension,
                    interior_shape, bandwidth, int(local.nnz)))
        self.schur = (self.schur + self.schur.T) * .5
        self.diagonal = np.diag(self.schur).copy()
        if np.min(self.diagonal) <= 0:
            raise ArithmeticError('Schur diagonal is not positive')

    def condense(self, rhs):
        flat = np.asarray(rhs, dtype=float).reshape(self.size)
        reduced = flat[self.trace].copy()
        particulars = []
        for block in self.blocks:
            local = linalg.cho_solve_banded(block.factor, flat[block.indices],
                                           check_finite=False)
            reduced[block.trace_indices] -= block.coupling.T @ local
            particulars.append(local)
        return reduced, particulars


    def expand(self, trace_state, particulars=None):
        trace_state = np.asarray(trace_state, dtype=float).reshape(len(self.trace))
        flat = np.zeros(self.size)
        flat[self.trace] = trace_state
        for index, block in enumerate(self.blocks):
            flat[block.indices] = -block.extension @ trace_state[block.trace_indices]
            if particulars is not None:
                flat[block.indices] += particulars[index]
        return flat.reshape(self.n, self.n)

def trace_space(schur, candidates, cutoff=1e-10):
    """Return A-orthonormal row vectors and their actions."""
    directions = np.asarray(candidates, dtype=float).reshape(-1, len(schur))
    norms = np.linalg.norm(directions, axis=1)
    keep = norms > 1e-25
    if not np.any(keep):
        return np.empty((0, len(schur))), np.empty((0, len(schur)))
    directions = directions[keep] / norms[keep, None]
    actions = directions @ schur
    gram = directions @ actions.T
    values, vectors = linalg.eigh((gram + gram.T) * .5)
    retained = values > max(1e-20, cutoff * values[-1])
    transform = vectors[:, retained].T / np.sqrt(values[retained, None])
    return transform @ directions, transform @ actions

class TraceInverse:
    """Balanced SPD Jacobi plus an A-orthonormal separator space."""

    def __init__(self, diagonal, basis, actions):
        self.diagonal = np.asarray(diagonal)
        self.basis, self.actions = basis, actions

    def apply(self, residual):
        residual = np.asarray(residual)
        if len(self.basis) == 0:
            return residual / self.diagonal
        coefficients = self.basis @ residual
        smooth = (residual - coefficients @ self.actions) / self.diagonal
        return coefficients @ self.basis + smooth - (self.actions @ smooth) @ self.basis
