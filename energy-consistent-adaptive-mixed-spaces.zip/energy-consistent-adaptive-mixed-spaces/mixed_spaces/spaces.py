"""Compartment enrichment in the Schur energy metric."""
import heapq
import time
import numpy as np
from scipy import linalg, ndimage
from scipy.sparse.linalg import splu

from .operators import coordinates, fixed_directions
from .condensation import trace_space

HIGH_THRESHOLD = 0.1
EXTRA_RANK = 18
RELATIVE_RANK_CUTOFF = 1e-9
STAGE_KEYS = ('components_seconds', 'global_bank_seconds', 'block_setup_seconds',
              'extension_seconds', 'energy_projection_seconds', 'ritz_seconds',
              'validation_seconds', 'overhead_seconds')

def mode_frequencies(count):
    return sorted(((i, j) for i in range(1, count + 1) for j in range(1, count + 1)),
                  key=lambda pair: (pair[0] ** 2 + pair[1] ** 2, pair))[:count]

ENVELOPE_FREQUENCIES = tuple(mode_frequencies(18))
FREQUENCIES = tuple(pair for pair in mode_frequencies(25) if pair != (4, 4))

def analytic_vectors(system, rank=24):
    if not 1 <= rank <= 24:
        raise ValueError('Analytic rank must be between 1 and 24')
    x, y = coordinates(system.n)
    return np.stack([np.sin(i * np.pi * x) * np.sin(j * np.pi * y)
                     for i, j in FREQUENCIES[:rank]]).reshape(rank, -1)[:, system.trace]

def protected_space(system, candidates):
    """Project against the protected span and order complementary Ritz directions."""
    fixed = fixed_directions(system.n, 6).reshape(6, -1)[:, system.trace]
    base, base_action = trace_space(system.schur, fixed)
    candidates = np.asarray(candidates, dtype=float)
    complement = candidates - (candidates @ base_action.T) @ base
    complement -= (complement @ base_action.T) @ base
    valid = np.linalg.norm(complement, axis=1) > np.maximum(1e-25, 1e-9 * np.linalg.norm(candidates, axis=1))
    complement = complement[valid]
    basis, actions = trace_space(system.schur, complement)
    if len(basis):
        projected = (actions / system.diagonal) @ actions.T
        values, rotations = linalg.eigh((projected + projected.T) * .5)
        basis, actions = rotations.T @ basis, rotations.T @ actions
    else:
        values = np.empty(0)
    return base, base_action, basis, actions, values

def prepare_bank(system, name='analytic'):
    """Build six protected and eighteen global complementary directions."""
    if name != 'analytic':
        raise ValueError("Foundation name must be 'analytic'")
    started = time.perf_counter()
    candidates = analytic_vectors(system)[6:]
    generated = time.perf_counter()
    bank = protected_space(system, candidates)
    decoded = time.perf_counter()
    if len(bank[0]) != 6 or len(bank[2]) != 18:
        raise ArithmeticError('The protected/global frame lost rank')
    return bank, {'candidate_seconds': generated-started,
                  'decoder_seconds': decoded-generated}

def containment_error(system, candidates, basis, actions):
    residual = candidates-(candidates@actions.T)@basis
    numerator = max(float(np.sum(residual*(residual@system.schur))), 0.)
    denominator = max(float(np.sum(candidates*(candidates@system.schur))), 1e-300)
    return float(np.sqrt(numerator/denominator))

def _components(coefficient):
    """Four-neighbor components, ordered by observable grid/material data."""
    high = np.asarray(coefficient) >= HIGH_THRESHOLD
    labels, count = ndimage.label(high, structure=np.array([[0, 1, 0],
                                                           [1, 1, 1],
                                                           [0, 1, 0]]))
    boundary = np.zeros_like(high)
    boundary[[0, -1], :] = True
    boundary[:, [0, -1]] = True
    components = []
    for label in range(1, count + 1):
        mask = labels == label
        indices = np.flatnonzero(mask.ravel())
        components.append({'label': label, 'nodes': len(indices),
                           'first_index': int(indices[0]),
                           'touches_boundary': bool(np.any(mask & boundary))})
    components.sort(key=lambda item: (item['touches_boundary'],
                                     -item['nodes'], item['first_index']))
    return high, labels, components

def _lazy_frequencies(n):
    """Yield sine frequencies in increasing (i*i+j*j, i, j) order."""
    if n < 1:
        return
    frontier, visited = [(2, 1, 1)], {(1, 1)}
    while frontier:
        _, i, j = heapq.heappop(frontier)
        yield i, j
        for first, second in ((i + 1, j), (i, j + 1)):
            if first <= n and second <= n and (first, second) not in visited:
                visited.add((first, second))
                heapq.heappush(frontier, (first * first + second * second, first, second))

def optimized_global36(system, count=36):
    """Complete a 36-direction global complement at the matched candidate budget."""
    if count <= 0 or count + 6 > len(system.trace):
        raise ValueError('Unsupported complementary dimension')
    fixed = fixed_directions(system.n, 6).reshape(6, -1)[:, system.trace]
    frame, _ = linalg.qr(fixed.T, mode='economic')
    x, y = coordinates(system.n)
    candidates, chosen, attempted = [], [], 0
    for i, j in _lazy_frequencies(system.n):
        attempted += 1
        value = (np.sin(i * np.pi * x) * np.sin(j * np.pi * y)).ravel()[system.trace]
        norm = np.linalg.norm(value)
        if norm < 1e-20:
            continue
        remainder = value - frame @ (frame.T @ value)
        remainder -= frame @ (frame.T @ remainder)
        remainder_norm = np.linalg.norm(remainder)
        if remainder_norm <= 1e-8 * norm:
            continue
        vector = remainder / remainder_norm
        candidates.append(vector)
        chosen.append([i, j])
        frame = np.column_stack((frame, vector))
        if len(candidates) == count:
            break
    if len(candidates) != count:
        raise ArithmeticError('Not enough independent mesh-only analytic directions')
    bank = protected_space(system, np.stack(candidates))
    if len(bank[2]) != count:
        raise ArithmeticError('Completed analytic control lost effective rank')
    return bank, {
        'requested_complement': count, 'candidate_rank': len(bank[2]),
        'frequencies': chosen, 'raw_attempted': attempted,
        'frequency_enumeration': 'lazy_ordered_heap',
        'euclidean_defect': float(np.linalg.norm(frame.T @ frame - np.eye(count + 6), ord=np.inf)),
    }

def _extension_solve(block, forcing, mode, factor=None):
    """Solve the low-conductivity extension with its existing sparse factor."""
    if mode != 'exact' or factor is None:
        raise ValueError("Exact extension requires mode='exact' and a sparse factor")
    forcing = np.asarray(forcing, dtype=np.float64)
    norm = float(np.linalg.norm(forcing))
    state = np.zeros_like(forcing) if norm == 0 else factor.solve(forcing)
    residual = forcing.copy() if norm == 0 else forcing-block@state
    remaining = float(np.linalg.norm(residual))
    if not np.all(np.isfinite(state)) or not np.isfinite(remaining):
        raise ArithmeticError('Nonfinite material extension')
    return state, {
        'iteration_budget': 0, 'iterations': 0,
        'direct_solves': int(norm > 0), 'solver_matvecs': 0,
        'residual_matvecs': int(norm > 0),
        'termination': 'direct' if norm > 0 else 'zero_rhs',
        'forcing_norm': norm, 'residual_norm': remaining,
        'relative_residual': remaining/norm if norm else 0.,
        'extension_energy': float(state@(forcing-residual))
    }

def _finalize_timing(stages, started):
    elapsed = time.perf_counter() - started
    stages['overhead_seconds'] = max(0., elapsed - sum(stages.values()))
    stages['total_seconds'] = sum(stages.values())
    return stages

class EnergyFrame:
    """Two-pass projection in an SPD metric, with explicit final actions.

    Recompute S r after both projection passes instead of accumulating actions
    by subtraction; accepted norms therefore use the actual residual vector.
    The initial frame must already be S-orthonormal. All arrays are owned here.
    """

    def __init__(self, schur, basis, actions, capacity):
        self.schur = np.asarray(schur, dtype=float)
        n = self.schur.shape[0]
        if self.schur.shape != (n, n) or basis.shape != actions.shape or basis.shape[1] != n:
            raise ValueError('Incompatible energy-frame shapes')
        if capacity < len(basis) or not np.all(np.isfinite(self.schur)):
            raise ValueError('Invalid energy-frame capacity or matrix')
        self.size = len(basis)
        self.basis = np.empty((capacity, n))
        self.actions = np.empty((capacity, n))
        self.basis[:self.size], self.actions[:self.size] = basis, actions
        if np.linalg.norm(basis @ actions.T-np.eye(self.size), ord=np.inf) > 1e-7:
            raise ArithmeticError('Initial energy frame is not orthonormal')
        self.matrix_actions = 0

    def append(self, raw):
        if self.size == len(self.basis):
            raise ValueError('Energy-frame capacity exceeded')
        raw = np.asarray(raw, dtype=float)
        if raw.shape != (self.schur.shape[0],) or not np.all(np.isfinite(raw)):
            raise ValueError('Invalid candidate')
        raw_action = self.schur @ raw
        self.matrix_actions += 1
        norm_squared = float(raw @ raw_action)
        if norm_squared < 0 or not np.isfinite(norm_squared):
            raise ArithmeticError('Nonpositive candidate metric')
        norm = np.sqrt(norm_squared)
        if norm <= 1e-25:
            return False, 0.
        residual = raw.copy()
        for _ in range(2):
            residual -= (self.actions[:self.size] @ residual) @ self.basis[:self.size]
        action = self.schur @ residual
        self.matrix_actions += 1
        remaining_squared = float(residual @ action)
        if remaining_squared < 0 or not np.isfinite(remaining_squared):
            raise ArithmeticError('Nonpositive projected metric')
        remaining = np.sqrt(remaining_squared)
        if remaining <= max(1e-25, RELATIVE_RANK_CUTOFF * norm):
            return False, float(remaining/norm)
        self.basis[self.size] = residual/remaining
        self.actions[self.size] = action/remaining
        self.size += 1
        return True, float(remaining/norm)

def energy_control_space(system):
    started = time.perf_counter()
    stages = {key: 0. for key in STAGE_KEYS}
    tick = time.perf_counter()
    coefficient = np.asarray(system.operator.a)
    if not np.all(np.isfinite(coefficient)) or np.any(coefficient <= 0) or len(system.trace) < 42:
        raise ValueError('Invalid coefficient or insufficient trace dimension')
    high, labels, components = _components(coefficient)
    high_indices, low_indices = np.flatnonzero(high.ravel()), np.flatnonzero(~high.ravel())
    stages['components_seconds'] += time.perf_counter()-tick
    detail = {'construction': 'direct_energy_frame', 'component_count': len(components),
              'components': components, 'candidate_rank': 36, 'protected_rank': 6,
              'retained_complement': 18, 'schur_cholesky_factorizations': 0,
              'information': 'coefficient_and_discrete_operator',
              'high_nodes': len(high_indices), 'extension_nodes': len(low_indices),
              'rank_cutoff': RELATIVE_RANK_CUTOFF, 'projection_passes': 2,
              'full_matrix_reassemblies': 0}
    if len(components) < 2:
        tick = time.perf_counter()
        bank, global_detail = optimized_global36(system)
        stages['global_bank_seconds'] += time.perf_counter()-tick
        tick = time.perf_counter()
        basis, actions = np.concatenate((bank[0], bank[2])), np.concatenate((bank[1], bank[3]))
        defect = float(np.linalg.norm(basis@actions.T-np.eye(42), ord=np.inf))
        contained = containment_error(system, analytic_vectors(system), basis, actions)
        if defect > 1e-7 or contained > 1e-7:
            raise ArithmeticError('Invalid global fallback')
        stages['validation_seconds'] += time.perf_counter()-tick
        detail.update(component_accepted_rank=0, component_accepted=[], component_raw_attempted=0,
                      component_rank_rejections=0, fallback_rank=18,
                      fallback_frequencies=global_detail['frequencies'],
                      fallback_route='completed_global_short_circuit',
                      global_detail=global_detail, extension_records=[], extension_rhs_count=0,
                      extension_solves=0, extension_factorizations=0, extension_breakdowns=0,
                      energy_frame_matrix_actions=0, full_gram_defect=defect, global_containment_error=contained)
        detail['timings'] = _finalize_timing(stages, started)
        return bank, detail
    tick = time.perf_counter()
    base, ba, global_comp, global_ca, global_values = prepare_bank(system, 'analytic')[0]
    stages['global_bank_seconds'] += time.perf_counter()-tick
    tick = time.perf_counter()
    global_basis, global_actions = np.concatenate((base, global_comp)), np.concatenate((ba, global_ca))
    frame = EnergyFrame(system.schur, global_basis, global_actions, 42)
    stages['energy_projection_seconds'] += time.perf_counter()-tick
    tick = time.perf_counter()
    block = coupling = factor = None
    if len(low_indices):
        block = system.matrix[low_indices][:, low_indices].tocsr()
        coupling = system.matrix[low_indices][:, high_indices].tocsr()
        factor = splu(block.tocsc())
    stages['block_setup_seconds'] += time.perf_counter()-tick
    tick = time.perf_counter()
    x, y = coordinates(system.n)
    masks = [(labels == item['label']).ravel() for item in components]
    stages['extension_seconds'] += time.perf_counter()-tick
    accepted_sources, records, relative_norms, fallback = [], [], [], []
    attempted = rejections = fallback_attempted = 0
    for frequency in (None,)+ENVELOPE_FREQUENCIES:
        tick = time.perf_counter()
        envelope = (np.ones_like(x) if frequency is None else
                    np.sin(frequency[0]*np.pi*x)*np.sin(frequency[1]*np.pi*y)).ravel()
        stages['extension_seconds'] += time.perf_counter()-tick
        for component, mask in zip(components, masks):
            tick = time.perf_counter()
            field = envelope*mask
            source = {'label': component['label'], 'kind': 'constant' if frequency is None else 'sine_envelope',
                      'frequency': None if frequency is None else list(frequency)}
            if block is not None:
                forcing = -(coupling @ field[high_indices])
                field[low_indices], work = _extension_solve(block, forcing, 'exact', factor=factor)
                records.append({**source, **work})
            stages['extension_seconds'] += time.perf_counter()-tick
            tick = time.perf_counter()
            accepted, relative_norm = frame.append(field[system.trace])
            stages['energy_projection_seconds'] += time.perf_counter()-tick
            attempted += 1
            if block is not None:
                records[-1]['accepted'] = accepted
            if accepted:
                accepted_sources.append(source)
                relative_norms.append(relative_norm)
            else:
                rejections += 1
            if frame.size == 42:
                break
        if frame.size == 42:
            break
    component_rank = len(accepted_sources)
    if frame.size < 42:
        for i, j in _lazy_frequencies(system.n):
            tick = time.perf_counter()
            raw = (np.sin(i*np.pi*x)*np.sin(j*np.pi*y)).ravel()[system.trace]
            stages['extension_seconds'] += time.perf_counter()-tick
            tick = time.perf_counter()
            accepted, relative_norm = frame.append(raw)
            stages['energy_projection_seconds'] += time.perf_counter()-tick
            fallback_attempted += 1
            if accepted:
                fallback.append([i, j])
                relative_norms.append(relative_norm)
            if frame.size == 42:
                break
    if frame.size != 42:
        raise ArithmeticError('Could not complete candidate rank 36')
    tick = time.perf_counter()
    complement, actions = frame.basis[6:].copy(), frame.actions[6:].copy()
    projected = (actions/system.diagonal) @ actions.T
    values, rotation = linalg.eigh((projected+projected.T)*.5)
    complement, actions = rotation.T@complement, rotation.T@actions
    stages['ritz_seconds'] += time.perf_counter()-tick
    tick = time.perf_counter()
    basis, all_actions = np.concatenate((base, complement)), np.concatenate((ba, actions))
    defect = float(np.linalg.norm(basis@all_actions.T-np.eye(42), ord=np.inf))
    contained = containment_error(system, global_basis, basis, all_actions)
    monotonicity = float(np.max(values[:18]-global_values))
    action_error = float(np.linalg.norm(all_actions-basis@system.schur)/np.linalg.norm(all_actions))
    if max(defect, contained, action_error) > 1e-7 or monotonicity > 1e-9:
        raise ArithmeticError('Energy frame failed space validation')
    stages['validation_seconds'] += time.perf_counter()-tick
    detail.update(component_accepted_rank=component_rank, component_accepted=accepted_sources,
                  component_raw_attempted=attempted, component_rank_rejections=rejections,
                  fallback_rank=len(fallback), fallback_frequencies=fallback,
                  fallback_raw_attempted=fallback_attempted,
                  fallback_route='sequential_energy_completion' if fallback else 'none',
                  extension_records=records, extension_rhs_count=len(records),
                  extension_solves=sum(r['direct_solves'] for r in records),
                  extension_factorizations=int(factor is not None), extension_breakdowns=0,
                  energy_frame_matrix_actions=frame.matrix_actions,
                  min_accepted_relative_energy_norm=min(relative_norms),
                  full_gram_defect=defect, global_containment_error=contained,
                  max_ritz_difference_from_global18=monotonicity, action_relative_error=action_error)
    detail['timings'] = _finalize_timing(stages, started)
    return (base, ba, complement, actions, values), detail
