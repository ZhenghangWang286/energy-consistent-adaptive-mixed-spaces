"""Discrete diffusion operators and global trace functions."""
import numpy as np
from scipy import sparse

def coordinates(n):
    grid = np.arange(1, n + 1, dtype=float) / (n + 1)
    return np.meshgrid(grid, grid, indexing='ij')

class Diffusion:
    """Symmetric harmonic-face diffusion with homogeneous Dirichlet data."""

    def __init__(self, coefficient, reaction=.2):
        a = np.asarray(coefficient, dtype=float)
        if (a.ndim != 2 or a.shape[0] != a.shape[1] or a.size == 0
                or not np.all(np.isfinite(a)) or np.min(a) <= 0
                or not np.isfinite(reaction) or reaction < 0):
            raise ValueError('A finite positive square field and nonnegative reaction are required')
        self.n = a.shape[0]
        self.shape = a.shape
        self.a = a.copy()
        self.reaction = float(reaction)
        scale = (self.n + 1) ** 2
        self.wx = 2 * a[1:] * a[:-1] / (a[1:] + a[:-1]) * scale
        self.wy = 2 * a[:, 1:] * a[:, :-1] / (a[:, 1:] + a[:, :-1]) * scale
        self.boundary = np.zeros_like(a)
        self.boundary[0] += scale * a[0]
        self.boundary[-1] += scale * a[-1]
        self.boundary[:, 0] += scale * a[:, 0]
        self.boundary[:, -1] += scale * a[:, -1]
        self.diagonal = self.boundary + reaction
        self.diagonal[1:] += self.wx
        self.diagonal[:-1] += self.wx
        self.diagonal[:, 1:] += self.wy
        self.diagonal[:, :-1] += self.wy

    def apply(self, value):
        value = np.asarray(value)
        result = (self.boundary + self.reaction) * value
        dx = self.wx * (value[..., 1:, :] - value[..., :-1, :])
        dy = self.wy * (value[..., :, 1:] - value[..., :, :-1])
        result[..., 1:, :] += dx
        result[..., :-1, :] -= dx
        result[..., :, 1:] += dy
        result[..., :, :-1] -= dy
        return result

    def matrix(self):
        ids = np.arange(self.n ** 2).reshape(self.shape)
        rows = [ids.ravel()]
        cols = [ids.ravel()]
        vals = [self.diagonal.ravel()]
        for first, second, weight in (
            (ids[:-1], ids[1:], self.wx),
            (ids[:, :-1], ids[:, 1:], self.wy),
        ):
            rows.extend([first.ravel(), second.ravel()])
            cols.extend([second.ravel(), first.ravel()])
            vals.extend([-weight.ravel(), -weight.ravel()])
        return sparse.coo_matrix((np.concatenate(vals),
                                  (np.concatenate(rows), np.concatenate(cols))),
                                 shape=(self.n ** 2, self.n ** 2)).tocsr()

def fixed_directions(n, count):
    x, y = coordinates(n)
    frequencies = sorted(((i, j) for i in range(1, count + 1) for j in range(1, count + 1)),
                         key=lambda pair: (pair[0] ** 2 + pair[1] ** 2, pair))[:count]
    return np.stack([np.sin(i * np.pi * x) * np.sin(j * np.pi * y) for i, j in frequencies])
