"""Exact local factor and particular-response reuse across material changes."""
from dataclasses import dataclass
import time
import numpy as np
from scipy import linalg

from .condensation import BandedCondensedSystem, BandedInteriorBlock, _pack_lower_band
from .queries import expand_batch
from .operators import Diffusion

QUERY_STAGES = ('preparation_seconds', 'condensation_seconds', 'interface_seconds',
                'expansion_seconds', 'full_solve_seconds', 'residual_seconds',
                'overhead_seconds')

@dataclass(frozen=True)
class LocalEntry:
    block: BandedInteriorBlock
    packed: np.ndarray
    gram: np.ndarray

@dataclass(frozen=True)
class LocalResponses:
    system: object
    loads: np.ndarray
    particulars: tuple

class ReusableCondensedSystem(BandedCondensedSystem):
    def __init__(self, operator, partitions=4, previous=None):
        n = operator.n
        if type(partitions) is not int or not 2 <= partitions <= n//2:
            raise ValueError('Integer partitions with nonempty interiors required')
        if previous is not None and (not isinstance(previous, ReusableCondensedSystem)
                                     or previous.n != n or previous.partitions != partitions):
            raise ValueError('Incompatible local cache')
        self.operator, self.n, self.size, self.partitions = operator, n, n*n, partitions
        self.matrix = operator.matrix()
        cuts = np.array([n*j//partitions-1 for j in range(1, partitions)], dtype=int)
        self.mask = np.zeros((n, n), dtype=bool)
        self.mask[cuts, :] = True
        self.mask[:, cuts] = True
        self.trace = np.flatnonzero(self.mask.ravel())
        self.schur = self.matrix[self.trace][:, self.trace].toarray()
        starts, ends = np.r_[0, cuts+1], np.r_[cuts, n]
        grid = np.arange(self.size).reshape(n, n)
        self.blocks, self.entries, self.reuse = [], [], []
        for sx, ex in zip(starts, ends):
            for sy, ey in zip(starts, ends):
                indices = grid[sx:ex, sy:ey].ravel()
                shape = (int(ex-sx), int(ey-sy))
                local = self.matrix[indices][:, indices].tocsr()
                packed, bandwidth = _pack_lower_band(local, shape)
                cross = self.matrix[indices][:, self.trace]
                touched = np.unique(cross.indices)
                coupling = cross[:, touched].toarray()
                old = previous.entries[len(self.entries)] if previous is not None else None
                same_local = old is not None and np.array_equal(old.packed, packed)
                same_cross = old is not None and np.array_equal(old.block.trace_indices, touched) and np.array_equal(old.block.coupling, coupling)
                if same_local and same_cross:
                    entry = old
                else:
                    factor = old.block.factor if same_local else (
                        linalg.cholesky_banded(packed, lower=True, check_finite=False), True)
                    extension = linalg.cho_solve_banded(factor, coupling, check_finite=False)
                    gram = coupling.T@extension
                    block = BandedInteriorBlock(indices, touched, factor, coupling, extension,
                                                shape, bandwidth, int(local.nnz))
                    entry = LocalEntry(block, packed, gram)
                    for array in (packed, gram, coupling, extension, factor[0], indices, touched):
                        array.setflags(write=False)
                self.schur[np.ix_(touched, touched)] -= entry.gram
                self.entries.append(entry)
                self.blocks.append(entry.block)
                self.reuse.append({'block': len(self.entries)-1, 'factor_reused': bool(same_local),
                                   'response_operator_reused': bool(same_local and same_cross)})
        self.schur = (self.schur+self.schur.T)*.5
        self.diagonal = np.diag(self.schur).copy()
        if np.min(self.diagonal) <= 0:
            raise ArithmeticError('Nonpositive Schur diagonal')

    def cache_metadata(self):
        return {'blocks': self.reuse, 'block_count': len(self.blocks),
                'factors_reused': sum(b['factor_reused'] for b in self.reuse),
                'response_operators_reused': sum(b['response_operator_reused'] for b in self.reuse),
                'extra_packed_and_gram_bytes': sum(e.packed.nbytes+e.gram.nbytes for e in self.entries),
                'scope': 'Bytes in retained packed-band matrices and local coupling Gram matrices.'}


def build_reusable(coefficient, previous=None):
    value = np.asarray(coefficient, dtype=float)
    if value.ndim != 2 or value.shape[0] != value.shape[1] or not np.all(np.isfinite(value)) or np.min(value) <= 0:
        raise ValueError('Finite positive square coefficient field required')
    operator = Diffusion(value)
    system = ReusableCondensedSystem(operator, 4, previous)
    factor = linalg.cho_factor(system.schur, lower=True, check_finite=False)
    return {'kind': 'schur_direct', 'system': system, 'operator': operator, 'factor': factor, 'rank': 0}


def solve_responses(context, loads, previous=None):
    started = time.perf_counter()
    loads = np.asarray(loads, dtype=float)
    system = context['system']
    if not isinstance(system, ReusableCondensedSystem):
        raise ValueError('A reusable context is required')
    if loads.ndim != 3 or loads.shape[1:] != (system.n, system.n) or not len(loads) or not np.all(np.isfinite(loads)):
        raise ValueError('A finite compatible load batch is required')
    norms = np.linalg.norm(loads.reshape(len(loads), -1), axis=1)
    if np.any(norms <= 0):
        raise ValueError('Nonzero loads required')
    if previous is not None and (not isinstance(previous, LocalResponses) or previous.loads.shape != loads.shape
                                 or previous.system.n != system.n or previous.system.partitions != system.partitions):
        raise ValueError('Incompatible local response cache')
    stages = dict.fromkeys(QUERY_STAGES, 0.)
    stages['preparation_seconds'] = time.perf_counter()-started
    tick = time.perf_counter()
    flat = loads.reshape(len(loads), -1).T
    reduced = flat[system.trace].copy()
    particulars, reused = [], []
    for j, block in enumerate(system.blocks):
        old = previous.system.entries[j] if previous is not None else None
        same_operator = old is not None and np.array_equal(system.entries[j].packed, old.packed)
        same_rhs = previous is not None and np.array_equal(loads.reshape(len(loads), -1)[:, block.indices],
                                                         previous.loads.reshape(len(loads), -1)[:, block.indices])
        if same_operator and same_rhs:
            local = previous.particulars[j]
        else:
            local = linalg.cho_solve_banded(block.factor, flat[block.indices], check_finite=False)
        reduced[block.trace_indices] -= block.coupling.T@local
        particulars.append(local)
        reused.append(bool(same_operator and same_rhs))
    reduced = np.ascontiguousarray(reduced.T)
    stages['condensation_seconds'] = time.perf_counter()-tick
    tick = time.perf_counter()
    traces = linalg.cho_solve(context['factor'], reduced.T, check_finite=False).T
    stages['interface_seconds'] = time.perf_counter()-tick
    tick = time.perf_counter()
    states = expand_batch(system, traces, particulars)
    stages['expansion_seconds'] = time.perf_counter()-tick
    tick = time.perf_counter()
    residuals = np.linalg.norm((loads-context['operator'].apply(states)).reshape(len(loads), -1), axis=1)/norms
    if not np.all(np.isfinite(residuals)) or max(residuals) > 1.05e-8:
        raise ArithmeticError('Original residual requirement failed')
    stages['residual_seconds'] = time.perf_counter()-tick
    # Own the source values: a caller changing its RHS array cannot poison reuse.
    cached_loads = loads.copy()
    cached_loads.setflags(write=False)
    for local in particulars:
        local.setflags(write=False)
    cache = LocalResponses(system, cached_loads, tuple(particulars))
    elapsed = time.perf_counter()-started
    stages['overhead_seconds'] = elapsed-sum(stages.values())
    if stages['overhead_seconds'] < -1e-12:
        raise ArithmeticError('Negative query clock remainder')
    detail = {'iterations': [0]*len(loads), 'cg_info': [0]*len(loads), 'relative_residual': residuals.tolist(),
              'query_stages': stages, 'query_internal_seconds': elapsed, 'particulars_reused': reused,
              'response_cache_bytes': cached_loads.nbytes+sum(p.nbytes for p in particulars)}
    return states, detail, cache
